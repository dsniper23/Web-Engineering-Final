module.exports = {
  bracketSpacing: true,
  printWidth: 120,
  singleQuote: true,
  semi: false,
  trailingComma: 'es5',
};
