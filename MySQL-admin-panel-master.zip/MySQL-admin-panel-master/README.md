# MySQL-admin-panel
MySQL Admin Panel is a simple platform built for performing basic operations (insert, update and delete) on a single table maintained in MySQL. The operations performed are done in PHP.
<hr>
The current example uses a student record having First Name and Last Name of student. Along with that it takes marks scored by every student. Using the marks, it is determined whether the student has passed or failed the exam.
<ul>
	<li>If student has scored below 40, (s)he is considered to be fail otherwise pass.</li>
	<li>If student marks are entered wrongly (i.e., more than 100 or a negative number) then that student record is marked in warning colour scheme.</li>
</ul>
<hr>
Screenshots
![Alt text](http://www.prabhakargupta.com/projects/ss/screencapture-localhost-test-index-php-1440962722309.png "Home Screen")
![Alt text](http://www.prabhakargupta.com/projects/ss/screencapture-localhost-test-index-php-1440962752918.png "Instructions")
